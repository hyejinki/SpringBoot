package com.chat.chatgpttest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatgptTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatgptTestApplication.class, args);
	}

}
