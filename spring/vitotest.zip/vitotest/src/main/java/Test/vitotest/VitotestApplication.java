package Test.vitotest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VitotestApplication {

	public static void main(String[] args) {
		SpringApplication.run(VitotestApplication.class, args);
	}

}
